<?php

namespace RobiKr\levelapi;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\utils\Config;
use pocketmine\Player;

class RLevelAPI extends PluginBase implements Listener 
{
	public $data;
	
	public $db;
	
	public static $instance = null;
	
	public static function getInstance() :?RLevelAPI
	{
		return self::$instance;
	} 
	public function onLoad()
	{
		self::$instance = $this;
	}
	
	public function onEnable()
	{
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		
		@mkdir($this->getDataFolder());
		$this->data = new Config($this->getDataFolder() . "data.yml" , Config::YAML , [
		"level" => [],
		"exp" => []
		]);
		$this->db = $this->data->getAll();
	}
	
	public function Join(PlayerJoinEvent $e)
	{
		$name = $e->getPlayer()->getName();
		if (!isset($this->db["level"][$name])) {
			$this->db["level"][$name] = 1;
			$this->db["exp"][$name] = 0;
			$this->save();
		}
	}
	
	public function getLevel(Player $player)
	{//레벨을 불러옵니다
		$name = $player->getName();
		$level = $this->db["level"][$name];
		if (isset($level)) {
			return $level;
		}
	}
	
	public function addLevel(Player $player, int $level)
	{//레벨을 추가합니다
		$name = $player->getName();
		if (isset($this->db["level"][$name])) {
			$this->db["level"][$name] += $level;
			$this->save();
		}
	}
	
	public function setLevel(Player $player, int $level)
	{//레벨을 설정합니다
		$name = $player->getName();
		if (isset($this->db["level"][$name])) {
			$this->db["level"][$name] = $level;
			$this->save();
		}
	}
	
	public function reduceLevel(Player $player, int $level)
	{//레벨을 뺍니다
		$name = $player->getName();
		if (isset($this->db["level"][$name])) {
			$this->db["level"][$name] -= $level;
			$this->save();
		}
	}
	
	public function getExp(Player $player)
	{//경험치를 불러옵니다
		$name = $player->getName();
		$exp = $this->db["exp"][$name];
		if (isset($exp)) {
			return $exp;
		}
	}
	
	public function addExp(Player $player, int $exp)
	{//경험치를 추가합니다
		$name = $player->getName();
		if (isset($this->db["exp"][$name])) {
			$this->db["exp"][$name] += $level;
			$this->save();
		}
	}
	
	public function setExp(Player $player, int $exp)
	{//경험치를 설정합니다
		$name = $player->getName();
		if (isset($this->db["exp"][$name])) {
			$this->db["exp"][$name] = $exp;
			$this->save();
		}
	}
	
	public function reduceExp(Player $player, int $exp)
	{//레벨을 뺍니다
		$name = $player->getName();
		if (isset($this->db["exp"][$name])) {
			$this->db["exp"][$name] -= $exp;
			$this->save();
		}
	}
	
	public function save()
	{
		$this->data->setAll($this->db);
		$this->data->save();
	}
}
	
	
	